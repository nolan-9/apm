import mongoose from 'mongoose';

const productSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, minlength: 2, maxlength: 100 },
  description: { type: String, trim: true, maxlength: 500, default: '' },
  price: { type: Number, required: true, min: 0 },
  category: { type: String, trim: true, maxlength: 60, default: 'General' },
}, { timestamps: true });

export default mongoose.model('Product', productSchema);
